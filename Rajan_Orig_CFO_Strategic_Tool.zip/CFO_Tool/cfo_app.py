import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

# --- 1. INITIALIZATION & CALLBACK ---
def reset_callback():
    st.session_state.li_widget = 0.0
    st.session_state.de_widget = 0.0
    st.session_state.growth_widget = 0.0
    st.session_state.li = 0.0
    st.session_state.de = 0.0
    st.session_state.growth = 0.0

if 'active' not in st.session_state:
    st.session_state.active = True
if 'li' not in st.session_state:
    st.session_state.li = 0.0

# --- 2. CORE LOGIC FUNCTIONS ---
def normalize(value, floor, ceiling, inverse=False):
    if inverse:
        if value >= floor: return 0.0
        if value <= ceiling: return 100.0
        return ((floor - value) / (floor - ceiling)) * 100
    else:
        if value <= floor: return 0.0
        if value >= ceiling: return 100.0
        return ((value - floor) / (ceiling - floor)) * 100

def create_dashboard_plot(growth, stability, efficiency):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 8), gridspec_kw={'width_ratios': [15, 1]})
    ax1.axhspan(70, 100, color='#2ecc71', alpha=0.2) 
    ax1.axhspan(40, 70, color='#f1c40f', alpha=0.2)  
    ax1.axhspan(0, 40, color='#e74c3c', alpha=0.2)   
    ax1.scatter(growth, stability, color='black', s=200, zorder=5)
    ax1.annotate(f'Status (S:{stability:.1f})', (growth, stability), xytext=(10, 10), textcoords='offset points', fontweight='bold', bbox=dict(boxstyle='round,pad=0.5', fc='white', alpha=0.8))
    ax1.set_xlim(-5, 60)
    ax1.set_ylim(0, 105)
    ax1.set_title("CFO Strategic Map (ACMA/CRISIL)", fontweight='bold', fontsize=16)
    ax1.set_xlabel("Revenue Growth Velocity (%)", fontweight='bold')
    ax1.set_ylabel("System Stability Index", fontweight='bold')
    ax2.axhspan(70, 100, color='#2ecc71', alpha=0.6)
    ax2.axhspan(40, 70, color='#f1c40f', alpha=0.6)
    ax2.axhspan(0, 40, color='#e74c3c', alpha=0.6)
    ax2.axhline(efficiency, color='black', linewidth=4)
    ax2.text(1.2, efficiency, f'← {efficiency:.1f}', va='center', fontweight='bold')
    ax2.set_ylim(0, 100)
    ax2.set_xticks([])
    return fig

# --- 3. UI RENDERING ---
if st.session_state.active:
    st.set_page_config(page_title="CFO Strategic Tool", layout="wide")
    st.title("🛡️ Strategic Assessment of the Liquidity-Leverage System")

    # Sidebar Inputs
    st.sidebar.header("Financial Inputs")
    li_val = st.sidebar.number_input("Liquidity Index (LI)", step=0.01, key="li_widget")
    de_val = st.sidebar.number_input("Debt/Equity Ratio (D/E)", step=0.01, key="de_widget")
    growth_val = st.sidebar.number_input("Revenue Growth (%)", step=1.0, key="growth_widget")

    # Calculations
    li_score = normalize(li_val, 1.2, 1.7)
    de_score = normalize(de_val, 3.0, 2.0, inverse=True)
    stability_index = (li_score + de_score) / 2
    efficiency_score = (stability_index + normalize(growth_val, 0, 50)) / 2

    st.pyplot(create_dashboard_plot(growth_val, stability_index, efficiency_score))

    # --- 4. ADVANCED 3D ANALYSIS (WITH GLOBAL AXIS KEY) ---
    st.divider()
    if st.checkbox("Show 3D Sensitivity Analysis", value=True):
        st.subheader("3D ROCE Sensitivity Projections")
        
        # Global Legend/Workaround
        st.markdown("""
        **Axis Map for all plots below:**
        * **X-Axis:** Liquidity Index (LI) [Range: 1.2 to 1.7]
        * **Y-Axis:** Debt/Equity Ratio (D/E) [Range: 2.0 to 3.0]
        * **Vertical Z-Axis:** **Raw ROCE (%)** [Scale: 0 to 45%]
        """)
        
        li_grid, de_grid = np.linspace(1.2, 1.7, 30), np.linspace(2.0, 3.0, 30)
        L, D = np.meshgrid(li_grid, de_grid)
        
        fig_3d = plt.figure(figsize=(24, 10))
        
        for i, g in enumerate([15, 30, 50]):
            ax = fig_3d.add_subplot(1, 3, i+1, projection='3d')
            Z_roce = (g * 0.35) + (L * 8) - (D * 3)
            ax.plot_surface(L, D, Z_roce, cmap='RdYlGn', alpha=0.8)
            
            ax.set_title(f"Scenario: {g}% Growth", fontsize=16, fontweight='bold', pad=15)
            
            # Simple axis labels to reduce clutter
            ax.set_xlabel("LI", fontsize=10)
            ax.set_ylabel("D/E", fontsize=10)
            # We keep the Z-label as a backup, but the st.markdown above is the primary source
            ax.set_zlabel("ROCE %", fontsize=10)
            
            ax.set_zlim(0, 45)
            ax.view_init(elev=20, azim=135)
            
        plt.subplots_adjust(wspace=0.3)
        st.pyplot(fig_3d)

    # --- 5. PROCESS CONTROL ---
    st.divider()
    st.subheader("Process Control")
    choice = st.radio("Do you want to continue?", ("Select", "Y (Reset)", "N (Exit)"), index=0)
    if "Y" in choice:
        st.button("Confirm: Reset to 0", on_click=reset_callback)
    if "N" in choice:
        if st.button("Confirm: Wipe & Exit"):
            st.session_state.active = False
            st.rerun()
else:
    st.title("Session Terminated")
    st.success("Financial data wiped. Dashboard offline.")
    st.stop()