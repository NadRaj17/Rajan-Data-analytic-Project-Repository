==========================================================
   STRATEGIC ASSESSMENT: LIQUIDITY-LEVERAGE SYSTEM
         Developed by: Rajan Narsinva Nadpurohit(Research Scholar)
==========================================================

OVERVIEW:
This tool is a Python-based Strategic Dashboard designed for CFOs
in the Indian Mid-Cap Auto Component Sector. It utilizes 
ACMA (2025) and CRISIL (2024) benchmarks to visualize 
financial stability and ROCE sensitivity in 3D.

PREREQUISITES:
1. Python 3.x installed (Download from https://www.python.org/)
2. An active internet connection for the FIRST launch only
   (to download required libraries).

HOW TO RUN:
1. Extract the 'CFO_Tool' folder to your Desktop.
2. Double-click the file named: Launcher_CFO_Tool.bat
3. The dashboard will automatically open in your default
   web browser at http://localhost:8501

FUNCTIONALITY NOTES:
- Use the sidebar to enter LI, D/E, and Revenue Growth.
- Scroll down to view 3D ROCE Sensitivity surfaces across
  15%, 30%, and 50% growth scenarios.
- Use the 'Process Control' section to Reset data to 0 or Exit.

DATA PRIVACY:
Choosing 'N (Exit & Wipe)' clears all session data and 
terminates the local server for security.
==========================================================