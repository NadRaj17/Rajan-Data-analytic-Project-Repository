@echo off
cd /d "D:\DBA\Walsh MS\MS Term 3\QM 640, Capstone Project\CFO_Tool"
streamlit run cfo_app.py
pause