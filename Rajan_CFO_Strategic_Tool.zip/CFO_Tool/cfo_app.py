import streamlit as st
import streamlit.components.v1 as components
import numpy as np
import plotly.graph_objects as go
import os
import time

# --- PAGE SETUP ---
st.set_page_config(page_title="CFO Strategic Tool", layout="wide")

# --- AUTO-FOCUS JAVASCRIPT ---
components.html(
    """
    <script>
    const doc = window.parent.document;
    const forceFocus = () => {
        const inputs = Array.from(doc.querySelectorAll('input[type="number"]'));
        const firstInput = inputs[0];
        if (firstInput && !firstInput.disabled) {
            firstInput.focus();
            return true;
        }
        return false;
    };
    let attempts = 0;
    const focusInterval = setInterval(() => {
        const success = forceFocus();
        attempts++;
        if (success || attempts > 15) clearInterval(focusInterval);
    }, 200);
    doc.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            const inputs = Array.from(doc.querySelectorAll('input[type="number"]'));
            const index = inputs.indexOf(doc.activeElement);
            if (index > -1 && index < inputs.length - 1) {
                inputs[index + 1].focus();
            } else if (index === inputs.length - 1) {
                const radio = doc.querySelector('input[type="radio"]');
                if (radio) radio.focus();
            }
        }
    });
    </script>
    """,
    height=0,
)

# --- SESSION STATE INITIALIZATION ---
if 'li_val' not in st.session_state: st.session_state['li_val'] = 0.00
if 'de_val' not in st.session_state: st.session_state['de_val'] = 0.00
if 'rev_val' not in st.session_state: st.session_state['rev_val'] = 0.00
if 'system_unlocked' not in st.session_state: st.session_state['system_unlocked'] = False

# --- SIDEBAR: FINANCIAL INPUTS ---
st.sidebar.header("Financial Inputs")
is_disabled = not st.session_state['system_unlocked']

li_raw = st.sidebar.number_input("Liquidity Index (LI)", value=st.session_state['li_val'], format="%.2f", disabled=is_disabled, key="li_box")
de_raw = st.sidebar.number_input("Debt/Equity Ratio (D/E)", value=st.session_state['de_val'], format="%.2f", disabled=is_disabled, key="de_box")
rev_raw = st.sidebar.number_input("Revenue Growth (%)", value=st.session_state['rev_val'], format="%.2f", disabled=is_disabled, key="rev_box")

st.session_state['li_val'], st.session_state['de_val'], st.session_state['rev_val'] = li_raw, de_raw, rev_raw

# --- DOCTORAL MATH ---
def normalize_vec(value, floor, ceiling, reverse=False):
    if not reverse: 
        return np.clip(((value - floor) / (ceiling - floor)) * 100, 0, 100)
    else: 
        return np.clip(((floor - value) / (floor - ceiling)) * 100, 0, 100)

n_li = normalize_vec(li_raw, 1.2, 1.7)
n_de = normalize_vec(de_raw, 3.0, 2.0, reverse=True)
n_growth = normalize_vec(rev_raw, 50, 15, reverse=True) if rev_raw > 15 else normalize_vec(rev_raw, 5, 15)

stability_score = (n_li + n_de) / 2
efficiency_score = (stability_score + n_growth) / 2

# --- MAIN UI ---
st.markdown("## **🛡️ Strategic Assessment of the Liquidity-Leverage System**")
st.markdown("<h5 style='text-align: center;'><b>CFO Strategic Map (ACMA/CRISIL Context)</b></h5>", unsafe_allow_html=True)

# 2D MAP
fig = go.Figure()
fig.add_hrect(y0=0, y1=40, fillcolor="#FFCCCC", opacity=0.5, line_width=0, annotation_text="<b>Structural Collapse</b>")
fig.add_hrect(y0=40, y1=70, fillcolor="#FFF4CC", opacity=0.5, line_width=0, annotation_text="<b>Working Capital Strain</b>")
fig.add_hrect(y0=70, y1=100, fillcolor="#CCFFCC", opacity=0.5, line_width=0, annotation_text="<b>Precision Zone</b>")

fig.add_trace(go.Scatter(x=[rev_raw], y=[stability_score], mode='markers+text', name='Stability', 
                         text=[f"<b>Stability: {stability_score:.1f}  </b>"], textposition="top left",
                         marker=dict(size=14, color='black', symbol='circle')))

fig.add_trace(go.Scatter(x=[rev_raw], y=[efficiency_score], mode='markers+text', name='Efficiency', 
                         text=[f"<b>  Efficiency: {efficiency_score:.1f}</b>"], textposition="bottom right",
                         marker=dict(size=14, color='blue', symbol='diamond', line=dict(width=2, color='white')), yaxis="y2"))

fig.update_layout(
    font=dict(family="Arial", size=12, color="black"),
    xaxis=dict(title="<b>Revenue Growth%</b>", range=[0, 60], gridcolor='lightgrey', tickfont=dict(weight='bold')),
    yaxis=dict(title="<b>Aggregated System Stability (LI & D/E balance)</b>", range=[0, 100], side="left", tickfont=dict(weight='bold')),
    yaxis2=dict(title="<b>Strategic Efficiency Score</b>", range=[0, 100], overlaying="y", side="right", showgrid=False, tickfont=dict(weight='bold')),
    height=550, margin=dict(l=50, r=50, b=50, t=50), plot_bgcolor='white', legend=dict(orientation="h", y=1.1, x=1, xanchor='right')
)
st.plotly_chart(fig, use_container_width=True)

# 3D PLOTS
st.divider()
if st.checkbox("Show 3D Sensitivity Analysis", value=True):
    def create_3d(g_scenario):
        li_r = np.linspace(1.2, 1.7, 15); de_r = np.linspace(2.0, 3.0, 15)
        LI, DE = np.meshgrid(li_r, de_r)
        Z = (((normalize_vec(LI, 1.2, 1.7) + normalize_vec(DE, 3.0, 2.0, True)) / 2) + 
             (normalize_vec(g_scenario, 50, 15, True) if g_scenario > 15 else normalize_vec(g_scenario, 5, 15))) / 2
        f = go.Figure(data=[go.Surface(z=Z, x=LI, y=DE, colorscale='RdYlGn', cmin=0, cmax=100)])
        f.update_layout(title=f"<b>Scenario: {g_scenario}% Growth</b>", scene=dict(xaxis_title='<b>LI</b>', yaxis_title='<b>D/E</b>', zaxis_title='<b>Eff</b>'), height=400, margin=dict(l=0, r=0, b=0, t=40))
        return f
    c1, c2, c3 = st.columns(3)
    with c1: st.plotly_chart(create_3d(15), use_container_width=True)
    with c2: st.plotly_chart(create_3d(30), use_container_width=True)
    with c3: st.plotly_chart(create_3d(50), use_container_width=True)

# --- PROCESS CONTROL ---
st.divider()
st.subheader("**Process Control**")
st.write("Do you want to continue?")
control = st.radio("System Control", ["Select", "Y (Reset)", "N (Exit)"], index=0, horizontal=True)

if control == "Y (Reset)":
    st.session_state['li_val'], st.session_state['de_val'], st.session_state['rev_val'] = 0.0, 0.0, 0.0
    st.session_state['system_unlocked'] = True
    st.rerun()

elif control == "N (Exit)":
    st.warning("⚠️ **Warning:** Proceeding will wipe all session data and terminate the simulation.")
    if st.button("**Confirm: Wipe Data & End Session**"):
        st.error("🛑 **DATA PURGED: Session Terminated.**")
        st.info("The local memory has been cleared. Closing terminal...")
        time.sleep(1) 
        st.session_state.clear()
        os._exit(0) # Hard exit to close the CMD window instantly

# Relock logic
if control == "Select":
    st.session_state['system_unlocked'] = False